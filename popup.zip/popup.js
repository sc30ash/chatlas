document.addEventListener('DOMContentLoaded', () => {
  // Elements
  const setupView = document.getElementById('setup-view');
  const progressView = document.getElementById('progress-view');
  const chatView = document.getElementById('chat-view');
  const statusEl = document.getElementById('status');
  const messagesEl = document.getElementById('messages');
  const progressBar = document.getElementById('progress-bar');
  const progressMsg = document.getElementById('progress-message');
  
  // Buttons
  const setupBtn = document.getElementById('setup-btn');
  const configBtn = document.getElementById('config-btn');
  
  // Forms
  const chatForm = document.getElementById('chat-form');
  
  // State
  let currentTaskId = null;
  let backendUrl = 'http://localhost:5000';
  let hfToken = '';
  let sitemapUrl = '';
  
  // Initialize
  loadSettings();
  
  // Event Listeners
  setupBtn.addEventListener('click', startProcessing);
  configBtn.addEventListener('click', showSetupView);
  chatForm.addEventListener('submit', handleChatSubmit);
  
  function loadSettings() {
      chrome.storage.sync.get(['hfToken', 'sitemapUrl'], (data) => {
        // Remove the backendUrl block entirely
        if (data.hfToken) {
          hfToken = data.hfToken;
          document.getElementById('hf_token').value = data.hfToken;
        }
        if (data.sitemapUrl) {
          sitemapUrl = data.sitemapUrl;
          document.getElementById('sitemap_url').value = data.sitemapUrl;
          statusEl.textContent = 'Sitemap configured';
        }
      });
    }
  
  function saveSettings() {
      chrome.storage.sync.set({ hfToken, sitemapUrl });
    }
  
  function showMessage(message, type = 'info') {
    messagesEl.innerHTML = `<div class="${type}">${message}</div>`;
    setTimeout(() => messagesEl.innerHTML = '', 3000);
  }
  
  function showSetupView() {
    setupView.style.display = 'block';
    progressView.style.display = 'none';
    chatView.style.display = 'none';
  }
  
  function showProgressView() {
    setupView.style.display = 'none';
    progressView.style.display = 'block';
    chatView.style.display = 'none';
  }
  
  function showChatView() {
    setupView.style.display = 'none';
    progressView.style.display = 'none';
    chatView.style.display = 'block';
  }
  
  function startProcessing() {
    // Get values
    hfToken = document.getElementById('hf_token').value;
    sitemapUrl = document.getElementById('sitemap_url').value;
    
    if (!backendUrl || !hfToken || !sitemapUrl) {
      showMessage('Please fill all fields', 'error');
      return;
    }
    
    // Save settings
    saveSettings();
    
    // Start processing
    fetch(`${backendUrl}/api/process`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        hf_token: hfToken,
        sitemap_url: sitemapUrl
      })
    })
    .then(response => response.json())
    .then(data => {
      if (data.error) {
        showMessage(data.error, 'error');
      } else {
        currentTaskId = data.task_id;
        showProgressView();
        checkProgress();
      }
    })
    .catch(error => {
      showMessage(`Failed to start processing: ${error.message}`, 'error');
    });
  }
  
  function checkProgress() {
    if (!currentTaskId) return;
    
    fetch(`${backendUrl}/api/progress/${currentTaskId}`)
      .then(response => response.json())
      .then(data => {
        progressBar.style.width = `${data.progress}%`;
        progressMsg.textContent = data.message;
        
        if (data.complete) {
          if (data.error) {
            showMessage(`Error: ${data.error}`, 'error');
            showSetupView();
          } else {
            statusEl.textContent = 'Sitemap loaded';
            showChatView();
          }
        } else {
          setTimeout(checkProgress, 1000);
        }
      })
      .catch(error => {
        showMessage(`Progress check failed: ${error.message}`, 'error');
        showSetupView();
      });
  }
  
  function handleChatSubmit(e) {
    e.preventDefault();
    const question = document.getElementById('question').value.trim();
    
    if (!question) return;
    
    const responseContainer = document.getElementById('response-container');
    responseContainer.innerHTML = '<div class="info">Processing...</div>';
    
    fetch(`${backendUrl}/api/chat`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        hf_token: hfToken,
        sitemap_url: sitemapUrl,
        question: question
      })
    })
    .then(response => response.json())
    .then(data => {
      if (data.error) {
        responseContainer.innerHTML = `<div class="error">${data.error}</div>`;
      } else {
        responseContainer.innerHTML = `
          <div class="response">
            ${data.response}
          </div>
        `;
      }
    })
    .catch(error => {
      responseContainer.innerHTML = `<div class="error">Request failed: ${error.message}</div>`;
    });
  }
});